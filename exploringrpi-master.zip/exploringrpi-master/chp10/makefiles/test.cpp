#include<iostream>
using namespace std;

int main() {
   int x = 1, y = 5;
   cout << "z = x + y = " << x+y << endl;
   return 0;
}
