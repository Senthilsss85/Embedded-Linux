#include<iostream>
using namespace std;

int main(){
   cout << "Hello from the RPi!" << endl;
   return 0;
}
