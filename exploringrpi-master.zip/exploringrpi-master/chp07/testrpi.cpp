#include<iostream>
using namespace std;

int main(){
   cout << "Testing cross compilation for the RPi" << endl;
   return 0;
}

