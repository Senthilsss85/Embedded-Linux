#include<iostream>
using namespace std;

int main(){
   int x = 5;
   x++;
   cout << "The value of x is " << x << endl;
}

